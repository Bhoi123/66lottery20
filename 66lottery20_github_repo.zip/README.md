# 66lottery20 Color Prediction Demo

Single-file static demo for practicing color-prediction strategies (no real money).

## Contents
- `index.html` — the single-file demo. Open locally in any browser.

## Purpose
This repository is for educational/demo use only. **Do not use for real gambling or money.**

## How to use locally
1. Download or clone this repository.
2. Open `index.html` in any browser (no server required).

## Deploy to GitHub Pages (quick)
1. Create a GitHub repo (e.g. `66lottery20-demo`) and push these files to the `main` branch.
2. In the repo settings -> Pages, select branch `main` and folder `/ (root)` and save.
3. Wait a minute — your site will be published at `https://<your-username>.github.io/<repo-name>/`

## License
MIT — see `LICENSE`

